import tkinter as tk
from tkinter import messagebox
from sympy import symbols, integrate, sympify, pretty, lambdify
import matplotlib.pyplot as plt
import numpy as np

# definimos una varibale simbolica para que Sympy pueda trabajar 
x = symbols('x')
def calcular_indefinida():
    try:
        funcion = sympify(entry_funcion.get()) # convierte la entrada en funcion sympy
        integral_indefinida = integarate(funcion, x) # calcula la integral indefinida

        # procedimiento y resultado
        procedimiento = f "∫ {pretty(funcion)} dx"
        resultado = pretty(integral_indefinida)

        # interfazz
        text_resultado.config(state=tk.NORMAL) # habilita EL CAMPO PARA ESCIRNIR
        text_reultado.delete(1.0, tk.END) #LIMPIA EL TEXTO
        text_resultado.insert(tk.END, f"Procediminiento:\n{procedimiento}\n\nResultado:\n{resultado} + C") # muestra el resultado
        text_resultado.config(state=tk.DISABLED)
    except Exception as e:
        messagebox.showerror"Error, f"Error al calcular: {str(e)}") 